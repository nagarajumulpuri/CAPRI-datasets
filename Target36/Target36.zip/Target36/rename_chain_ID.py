import os
import numpy as np
import math
import matplotlib.pyplot as plt
import operator

with open('list.dat', 'r') as fr_pdbs:
    for pdbs in fr_pdbs.readlines():
        in_file = "../Old-Target36/"+ str(pdbs).strip()
        out_file = str(pdbs).strip()
        with open(in_file, 'r') as fr:
            count = 0
            chain_new = 'A'
            with open(out_file, 'w') as fw:
                for lines in fr.readlines():
                    line = lines.split()
                    if str(line[0]).strip() == "TER" and line[0].strip() != "ENDMDL":
                        count += 1
                        chain_new = chr(ord(chain_new) + count)
                        fw.write("TER")
                        fw.write("\n")
                    if len(line) > 8:
                        new_line = lines[0:21] + chain_new + lines[22:78]
                        fw.write(new_line)
                        fw.write("\n")
                fw.write("ENDMDL")


